# Tokto Helm Chart

This Helm chart deploys the Tokto application stack, which includes a frontend, backend, and Redis components.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- AWS Load Balancer Controller installed in your cluster (for ALB Ingress)

## Installation

```bash
# Add any required secrets first
kubectl create secret generic env-secret --from-literal=SOME_SECRET=value

# Install the chart
helm install tokto ./tokto
```

For production deployments, create a values file:

```bash
helm install tokto ./tokto -f production-values.yaml
```

## Configuration

### Global Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `global.frontendDomain` | Frontend domain name (required) | `"ai.cloudhiro.com"` |
| `global.backendDomain` | Backend domain name (required) | `"ai-be.cloudhiro.com"` |
| `global.env.SPRING_REDIS_HOST` | Redis host | `"redis"` |
| `global.env.MYSQL_DATABASE` | MySQL database name | `"mlops"` |
| `global.env.FRONTEND_BACKEND_URL` | Backend URL for frontend | `"https://ai-be.cloudhiro.com"` |

### Database Credentials (Required)

```yaml
secrets:
  mysql:
    user: "your-username"
    password: "your-password"
```

### Backend Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `backend.image.repository` | Backend image repository | `public.ecr.aws/f3u3y6v0/tokto-backend` |
| `backend.image.tag` | Backend image tag | `"1.0"` |
| `backend.nodeSelector` | Node selector for backend pods | `{ "node.kubernetes.io/lifecycle": "ondemand" }` |

### Frontend Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `frontend.image.repository` | Frontend image repository | `public.ecr.aws/f3u3y6v0/tokto-frontend` |
| `frontend.image.tag` | Frontend image tag | `"1.0"` |
| `frontend.nodeSelector` | Node selector for frontend pods | `{ "node.kubernetes.io/lifecycle": "ondemand" }` |

### Redis Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `redis.enabled` | Enable Redis deployment | `true` |
| `redis.image.repository` | Redis image repository | `redis` |
| `redis.image.tag` | Redis image tag | `alpine` |
| `redis.nodeSelector` | Node selector for Redis pods | `{ "node.kubernetes.io/lifecycle": "ondemand" }` |

### Ingress Configuration

The chart uses AWS ALB Ingress Controller. Default configuration:

```yaml
ingress:
  enabled: true
  className: alb
  annotations:
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS":443}]'
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    alb.ingress.kubernetes.io/ssl-redirect: '443'
```

## Example Production Values

```yaml
global:
  frontendDomain: "ai.cloudhiro.com"
  backendDomain: "ai-be.cloudhiro.com"

secrets:
  mysql:
    user: "prod-user"
    password: "prod-password"

backend:
  image:
    tag: "1.0"
  resources:
    requests:
      memory: "512Mi"
      cpu: "250m"
    limits:
      memory: "1Gi"
      cpu: "500m"

frontend:
  image:
    tag: "1.0"
  resources:
    requests:
      memory: "128Mi"
      cpu: "100m"
    limits:
      memory: "256Mi"
      cpu: "200m"
```

## Upgrading

To upgrade the release:

```bash
helm upgrade tokto ./tokto -f production-values.yaml
```

## Uninstalling

To uninstall/delete the deployment:

```bash
helm uninstall tokto
```

## Development

To test the chart locally:

```bash
# Validate the chart
helm lint ./tokto

# Test template rendering
helm template test ./tokto

# Dry run
helm install --dry-run --debug test ./tokto
```

helm upgrade  -n mlops2  --create-namespace tokto --install \ 
--set collectorDeployment.initialToken=<initial token> \
cloudhiro/chi-metrics