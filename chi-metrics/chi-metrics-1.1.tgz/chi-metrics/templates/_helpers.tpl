{{/*
Expand the name of the chart.
*/}}
{{- define "chi-metrics.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "chi-metrics.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chi-metrics.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "chi-metrics.labels" -}}
helm.sh/chart: {{ include "chi-metrics.chart" . }}
{{ include "chi-metrics.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chi-metrics.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chi-metrics.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "chi-metrics.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "chi-metrics.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Derive the maintenance CronJob's schedule from maintenanceWindow.windowType + windowStart
(and windowDays / windowDaysOfMonth for weekly/monthly), so the CronJob actually fires at
windowStart instead of running on an independently-configured schedule that can drift out
of sync with the in-process window check (isMaintenanceWindowActive in maintenance.go).
windowStart is "HH:MM" (UTC) - same convention the Go binary uses.
*/}}
{{- define "chi-metrics.maintenanceCronSchedule" -}}
{{- $mw := .Values.maintenanceWindow }}
{{- $parts := splitList ":" $mw.windowStart }}
{{- $hour := atoi (index $parts 0) }}
{{- $minute := atoi (index $parts 1) }}
{{- if eq $mw.windowType "weekly" }}
{{- $dayNumbers := dict "sun" "0" "sunday" "0" "mon" "1" "monday" "1" "tue" "2" "tuesday" "2" "wed" "3" "wednesday" "3" "thu" "4" "thursday" "4" "fri" "5" "friday" "5" "sat" "6" "saturday" "6" }}
{{- $days := list }}
{{- range splitList "," $mw.windowDays }}
{{- $key := . | trim | lower }}
{{- if hasKey $dayNumbers $key }}
{{- $days = append $days (get $dayNumbers $key) }}
{{- end }}
{{- end }}
{{- $daysField := join "," $days }}
{{- if not $daysField }}
{{- $daysField = "*" }}
{{- end }}
{{- printf "%d %d * * %s" $minute $hour $daysField }}
{{- else if eq $mw.windowType "monthly" }}
{{- printf "%d %d %s * *" $minute $hour $mw.windowDaysOfMonth }}
{{- else }}
{{- printf "%d %d * * *" $minute $hour }}
{{- end }}
{{- end }}
